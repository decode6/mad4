package com.example.prog4;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    Button btn;
    ProgressBar prog;
    TextView t2;
    int count;
    AlertDialog.Builder build;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.button);
        build = new AlertDialog.Builder(this);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Alert_Message();
            }
        });
    }

    public void Alert_Message() {
        build.setTitle("Alert")
                .setMessage("Are you want to Continue")
                .setCancelable(true)
                .setIcon(R.mipmap.ic_launcher_foreground)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        progress_success();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                        prog.setVisibility(View.INVISIBLE);
                        t2.setVisibility(View.INVISIBLE);
                    }
                }).show();
    }

    public void progress_success() {
        prog = findViewById(R.id.progressBar);
        t2=findViewById(R.id.textView2);
        prog.setVisibility(View.VISIBLE);
        t2.setVisibility(View.VISIBLE);
        count = 0;
        final Timer t = new Timer();
        final TimerTask tt = new TimerTask() {
            @Override
            public void run() {
                count++;
                t2.setText(count+"%");
                prog.setProgress(count);
                if (count == 100) {
                    //t.cancel();
                    count=0;
                }
            }
        };
        t.schedule(tt,0,100);
    };


}

